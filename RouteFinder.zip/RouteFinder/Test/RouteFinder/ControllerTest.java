package RouteFinder;

import org.junit.Test;
import static org.junit.Assert.*;

public class ControllerTest {
    @Test
    public void numLandmarksTest() {
        assertEquals("The number of landmarks is incorrect", 26, Controller.numLandmarks());
    }
}