package RouteFinder;

// IMPORTS
import javafx.embed.swing.SwingFXUtils;

import java.awt.*;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import javafx.scene.image.Image;

public class Utilities {

    // Array of landmarks
    static String[] landmarks = {"Vatican Museums", "St. Peter's Basilica", "Sistine Chapel", "St. Peter's Square", "Castel Sant'Angelo",
            "National Museum of Rome", "Piazza Navona", "Campo de'Fiori", "People's Square", "Pantheon", "Piazaa di Spagna & the Spanish Steps",
            "Trevi Fountain", "Colonna Gallery", "Il Vittoriano", "Campidoglio Square", "Capuchin Cemetery", "Quirinale Palace",
            "Imperial Forums", "Roman Forum", "Palatino Hill", "Via Sacra", "Arch of Constantine", "Colosseum", "Villa Borghese",
            "Golden House", "Papal Basilica of Saint Mary Major"};

    // Edits the map image for adding each junctions
    public static Image bufferedLocation(int[] xPixel, int[] yPixel) {
        if(xPixel.length != yPixel.length)
         return null;
        // Creates blue squares to represent junctions
    BufferedImage bufferedImage = SwingFXUtils.fromFXImage(RouteFinder.Controller.unchangedImage,null);
    Color pixelColor = new Color(0,0,255);
    for(int k = 0; k < xPixel.length; k ++) {
        for (int i = xPixel[k] - 3; i < xPixel[k] + 3; i++) {
            for (int j = yPixel[k] - 3; j < yPixel[k] + 3; j++) {

                if (i < bufferedImage.getWidth() && i > -1) {
                    if (j < bufferedImage.getHeight() && j > -1) {
                        bufferedImage.setRGB(i, j, pixelColor.getRGB());
                    }
                }
            }
        }
    }
        return SwingFXUtils.toFXImage(bufferedImage, null);
    }
/*
    public static Image bufferedLine(Image img,double x1, double y1, double x2, double y2){
        BufferedImage bufferedImage = SwingFXUtils.fromFXImage(img,null);
        Graphics2D line =  bufferedImage.createGraphics();
        line.setColor(Color.red);
        line.fill(new Line2D.Float((float)x1, (float)y1, (float)x2, (float)y2));
        line.dispose();
        return SwingFXUtils.toFXImage(bufferedImage, null);
    }
    */
}