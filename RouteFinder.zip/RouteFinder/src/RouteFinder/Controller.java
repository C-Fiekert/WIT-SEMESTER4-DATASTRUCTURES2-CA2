package RouteFinder;                                                                          

// IMPORTS
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;

//JMH Benchmarking
//import org.openjdk.jmh.annotations.*;                                                                          
//import java.util.concurrent.TimeUnit;                                                                          
                                                                          
                                                                          
/*@Measurement(iterations = 10)                                                                          
@Warmup(iterations = 5)                                                                          
@Fork(value = 1)                                                                          
@BenchmarkMode(Mode.AverageTime)                                                                          
@OutputTimeUnit(TimeUnit.MILLISECONDS)                                                                          
@State(Scope.Thread)*/                                                                          
public class Controller {                                                                          
    @FXML                                                                          
    ChoiceBox language, start, destination, avoid, mustSee;
    @FXML                                                                          
    CheckBox show, show1;
    @FXML
    ImageView flag, back, mapView;
    @FXML                                                                          
    Pane pane;                                                                          
    @FXML                                                                          
    CheckBox djikstra, bfs, shortest, cultural;                                                                          
    @FXML                                                                          
    Menu options;
    @FXML                                                                          
    MenuItem exit;                                                                          
    @FXML                                                                          
    Button set, findRoute;
    @FXML
    Label routeSearch, routeType, start1, destination1;
    @FXML                                                                          
    Text msLand, avLand;
    @FXML
    Rectangle rec;
    @FXML
    Line line;
    static int[] pixel;
    // Map of Rome
    Image map = new Image("RouteFinder//rome-map.jpg", 650, 450, false, true);
    static Image unchangedImage;
    private int width = (int) map.getWidth();
    private int height = (int) map.getHeight();
    private Image italian = new Image("https://cdn1.iconfinder.com/data/icons/major-world-flags-1/512/italy_flag_circle-512.png");
    private Image english = new Image("https://cdn1.iconfinder.com/data/icons/world-flags-circular/1000/Flag_of_United_Kingdom_-_Circle-512.png");
    // Background Image
    private Image background = new Image("https://wallpaperaccess.com/full/817598.jpg", 920, 675, false, true);
    // Coordinate arrays of junctions
    private int[] xCoordsJunctions = new int[27],yCoordsJunctions  = new int[27];
    // Landmark and Junction nodes
    private Node<Coordinate>[] landmarks = new Node[26], junctions = new Node[27];

    public void initialize(){ 
        unchangedImage = map;                                                                          
        flag.setImage(english);                                                                          
        language.getItems().add("English");                                                                          
        language.getItems().add("Italiano");
        language.setValue("English");
        back.setImage(background);
        pixel = new int[width * height];                                                                          
        mapView.setImage(map);
        // Loads all nodes, connections and arrays
        try {
            load();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
                   
    // Toggles Landmarks on and off
    public void showLandmarks(){
        if (show.isSelected()) {
            for (int i = 0; i < 26; i++) {
                rec = new Rectangle(landmarks[i].data.getX(), landmarks[i].data.getY(), 6, 6);
                rec.setFill(Color.RED);
                //Hover over landmark
                Tooltip.install(rec, new Tooltip(Utilities.landmarks[i]));
                pane.getChildren().add(rec);
            }
        }
        else {
            pane.getChildren().clear();
        }
    }

    // Returns number of landmarks
    public static int numLandmarks(){
        return Utilities.landmarks.length;
    }

    // Toggle junctions off
    public void showJunctions(){
        if (show1.isSelected()) {
            mapView.setImage(Utilities.bufferedLocation(xCoordsJunctions, yCoordsJunctions));
        }
        else {
            mapView.setImage(map);
        }
    }

    // Find route method
    public void run() {
        pane.getChildren().clear();
        Node<Coordinate> first = landmarks[start.getSelectionModel().getSelectedIndex()];
        Coordinate dest = landmarks[destination.getSelectionModel().getSelectedIndex()].data;

        //Avoid Nodes
        List<NodeLink>[] nodesAvoided = null;
        int[] avoidNodes = null;
        if(avoid.getSelectionModel().getSelectedIndex() != -1) {
            avoidNodes = new int[1];
            for (int i = 0; i < avoidNodes.length; i++) {
                avoidNodes[i] = avoid.getSelectionModel().getSelectedIndex();
            }
            // Avoid selected node
            nodesAvoided = avoidnodes(avoidNodes);
        }

        Node<?> lastn = null;
        boolean searchingCultural = true;
        // All algorithms if a landmark must be visited
        if(mustSee.getSelectionModel().getSelectedIndex() != -1) {
            // Shortest Djikstra route
            if (djikstra.isSelected() && shortest.isSelected()) {
                System.out.println("-------------------------------------");
                // Goes to must see destination
                Node.CostedPath costedPathDijkstra1 = Node.findCheapestPathDijkstra(first, landmarks[mustSee.getSelectionModel().getSelectedIndex()].data);
                // Goes to destination
                Node.CostedPath costedPathDijkstra2 = Node.findCheapestPathDijkstra(landmarks[mustSee.getSelectionModel().getSelectedIndex()], dest);

                // Draws route on the map
                for (Node<?> n : costedPathDijkstra1.pathList) {
                    if (lastn != null) {
                        line = new Line(Double.parseDouble(n.data.toString().substring(0, 3)), Double.parseDouble(n.data.toString().substring(3, 6)),
                                Double.parseDouble(lastn.data.toString().substring(0, 3)), Double.parseDouble(lastn.data.toString().substring(3, 6)));
                        line.setStroke(Color.RED);
                        pane.getChildren().add(line);
                    }
                    lastn = n;
                }

                lastn  = null;
                for (Node<?> n : costedPathDijkstra2.pathList) {
                    if (lastn != null) {
                        line = new Line(Double.parseDouble(n.data.toString().substring(0, 3)), Double.parseDouble(n.data.toString().substring(3, 6)),
                                Double.parseDouble(lastn.data.toString().substring(0, 3)), Double.parseDouble(lastn.data.toString().substring(3, 6)));
                        line.setStroke(Color.RED);
                        pane.getChildren().add(line);
                    }
                    lastn = n;
                }

                System.out.println("\nThe total path cost is: " + costedPathDijkstra1.pathCost + costedPathDijkstra2.pathCost);

                // Cultural Djikstra rout
            } else if (djikstra.isSelected() && cultural.isSelected()) {
                Node.CostedPath costedCulural1 = Node.findCheapestPathDijkstra(first, landmarks[mustSee.getSelectionModel().getSelectedIndex()].data), lastpath = null, nullpath = null;
                ArrayList<List<NodeLink>> avoidedJunctions = new ArrayList<>(), lastpass = new ArrayList<>();
                ArrayList<Integer> avoidedIndex = new ArrayList<>();
                int failures = 0;
                while(searchingCultural){
                    for(int i = 0; i < junctions.length;i++){
                        for(Node<?> n : costedCulural1.pathList){
                            if(n == junctions[i]){
                                avoidedJunctions.add(junctions[i].avoidNode());
                                avoidedIndex.add(i);
                                costedCulural1 = Node.findCheapestPathDijkstra(first, dest);

                                if(costedCulural1 != nullpath) {
                                    junctions[i].reconnectNodes(junctions[i],avoidedJunctions.get(avoidedJunctions.size() -1));
                                    lastpass = avoidedJunctions;
                                    lastpath = costedCulural1;
                                    avoidedIndex.remove(avoidedIndex.get(avoidedIndex.size() - 1));
                                    System.out.print("Yes");
                                }
                                else{
                                    avoidedJunctions = lastpass;
                                    costedCulural1 = lastpath;
                                    junctions[i].reconnectNodes(junctions[i], avoidedJunctions.get(avoidedJunctions.size() -1));
                                    avoidedJunctions.remove(avoidedJunctions.get(avoidedJunctions.size() -1));
                                    failures++;
                                    System.out.print("No");
                                }
                            }
                        }
                    }
                    if(failures > 2){
                        for(int i = 0; i < avoidedJunctions.size(); i++){
                            junctions[avoidedIndex.get(i)].reconnectNodes(junctions[avoidedIndex.get(i)],avoidedJunctions.get(i));
                        }
                        searchingCultural = false;
                    }
                }
                for (Node<?> n : costedCulural1.pathList) {
                    if (lastn != null) {
                        line = new Line(Double.parseDouble(n.data.toString().substring(0, 3)), Double.parseDouble(n.data.toString().substring(3, 6)),
                                Double.parseDouble(lastn.data.toString().substring(0, 3)), Double.parseDouble(lastn.data.toString().substring(3, 6)));
                        line.setStroke(Color.RED);
                        pane.getChildren().add(line);
                    }
                    lastn = n;
                }

                Node.CostedPath costedCulural2 = Node.findCheapestPathDijkstra(landmarks[mustSee.getSelectionModel().getSelectedIndex()], dest);
                failures = 0;
                while(searchingCultural){
                    for(int i = 0; i < junctions.length;i++){
                        for(Node<?> n : costedCulural2.pathList){
                            if(n == junctions[i]){
                                avoidedJunctions.add(junctions[i].avoidNode());
                                avoidedIndex.add(i);
                                costedCulural2 = Node.findCheapestPathDijkstra(first, dest);

                                if(costedCulural2 != nullpath) {
                                    junctions[i].reconnectNodes(junctions[i],avoidedJunctions.get(avoidedJunctions.size() -1));
                                    lastpass = avoidedJunctions;
                                    lastpath = costedCulural2;
                                    avoidedIndex.remove(avoidedIndex.get(avoidedIndex.size() - 1));
                                    System.out.print("Yes");
                                }
                                else{
                                    avoidedJunctions = lastpass;
                                    costedCulural2 = lastpath;
                                    junctions[i].reconnectNodes(junctions[i], avoidedJunctions.get(avoidedJunctions.size() -1));
                                    avoidedJunctions.remove(avoidedJunctions.get(avoidedJunctions.size() -1));
                                    failures++;
                                    System.out.print("No");
                                }
                            }
                        }
                    }
                    if(failures > 2){
                        for(int i = 0; i < avoidedJunctions.size(); i++){
                            junctions[avoidedIndex.get(i)].reconnectNodes(junctions[avoidedIndex.get(i)],avoidedJunctions.get(i));
                        }
                        searchingCultural = false;
                    }
                }
                for (Node<?> n : costedCulural2.pathList) {
                    if (lastn != null) {
                        line = new Line(Double.parseDouble(n.data.toString().substring(0, 3)), Double.parseDouble(n.data.toString().substring(3, 6)),
                                Double.parseDouble(lastn.data.toString().substring(0, 3)), Double.parseDouble(lastn.data.toString().substring(3, 6)));
                        line.setStroke(Color.RED);
                        pane.getChildren().add(line);
                    }
                    lastn = n;
                }

                System.out.println("\nThe total path cost is: " + costedCulural2.pathCost + costedCulural1.pathCost);

                // BFS route
            } else if (bfs.isSelected()) {
                System.out.println("------------------------------------------");
                List<Node<?>> bfsPath1 = Node.findPathBreadthFirst(first, landmarks[mustSee.getSelectionModel().getSelectedIndex()].data),
                        bfsPath2 = Node.findPathBreadthFirst(landmarks[mustSee.getSelectionModel().getSelectedIndex()], dest);

                // Draws the route on the map
                for (Node<?> n : bfsPath1) {
                    if (lastn != null) {
                        line = new Line(Double.parseDouble(n.data.toString().substring(0, 3)), Double.parseDouble(n.data.toString().substring(3, 6)),
                                Double.parseDouble(lastn.data.toString().substring(0, 3)), Double.parseDouble(lastn.data.toString().substring(3, 6)));
                        line.setStroke(Color.RED);
                        pane.getChildren().add(line);
                    }
                    lastn = n;
                }

                lastn = null;
                for (Node<?> n : bfsPath2) {
                    if (lastn != null) {
                        line = new Line(Double.parseDouble(n.data.toString().substring(0, 3)), Double.parseDouble(n.data.toString().substring(3, 6)),
                                Double.parseDouble(lastn.data.toString().substring(0, 3)), Double.parseDouble(lastn.data.toString().substring(3, 6)));
                        line.setStroke(Color.RED);
                        pane.getChildren().add(line);
                    }
                    lastn = n;
                }
            }
            if (show.isSelected())
                show.setSelected(false);
            //Re-add Nodes
            if (avoid.getSelectionModel().getSelectedIndex() != -1) {
                reconnectNodes(nodesAvoided, avoidNodes);
            }
        }
        else{
            // Shortest Djikstra route
            if (djikstra.isSelected() && shortest.isSelected()) {
                System.out.println("-------------------------------------");
                Node.CostedPath costedPathDijkstra = Node.findCheapestPathDijkstra(first, dest);

                // Draws route on the map
                for (Node<?> n : costedPathDijkstra.pathList) {
                    if (lastn != null) {
                        line = new Line(Double.parseDouble(n.data.toString().substring(0, 3)), Double.parseDouble(n.data.toString().substring(3, 6)),
                                Double.parseDouble(lastn.data.toString().substring(0, 3)), Double.parseDouble(lastn.data.toString().substring(3, 6)));
                        line.setStroke(Color.RED);
                        pane.getChildren().add(line);
                    }
                    lastn = n;
                }
                System.out.println("\nThe total path cost is: " + costedPathDijkstra.pathCost);

                // Cultural Djikstra route
            } else if(djikstra.isSelected() && cultural.isSelected()) {
                Node.CostedPath costedCulural = Node.findCheapestPathDijkstra(first, dest), lastpath = null, nullpath = null;
                ArrayList<List<NodeLink>> avoidedJunctions = new ArrayList<>(), lastpass = new ArrayList<>();
                ArrayList<Integer> avoidedIndex = new ArrayList<>();
                int failures = 0;
                while(searchingCultural){
                    for(int i = 0; i < junctions.length;i++){
                        for(Node<?> n : costedCulural.pathList){
                            if(n == junctions[i]){
                                avoidedJunctions.add(junctions[i].avoidNode());
                                avoidedIndex.add(i);
                                costedCulural = Node.findCheapestPathDijkstra(first, dest);

                                if(costedCulural != nullpath) {
                                    junctions[i].reconnectNodes(junctions[i],avoidedJunctions.get(avoidedJunctions.size() -1));
                                    lastpass = avoidedJunctions;
                                    lastpath = costedCulural;
                                    avoidedIndex.remove(avoidedIndex.get(avoidedIndex.size() - 1));
                                    System.out.print("Yes");
                                }
                                else{
                                    avoidedJunctions = lastpass;
                                    costedCulural = lastpath;
                                    junctions[i].reconnectNodes(junctions[i], avoidedJunctions.get(avoidedJunctions.size() -1));
                                    avoidedJunctions.remove(avoidedJunctions.get(avoidedJunctions.size() -1));
                                    failures++;
                                    System.out.print("No");
                                }
                            }
                        }
                    }
                    if(failures > 2){
                        for(int i = 0; i < avoidedJunctions.size(); i++){
                            junctions[avoidedIndex.get(i)].reconnectNodes(junctions[avoidedIndex.get(i)],avoidedJunctions.get(i));
                        }
                        searchingCultural = false;
                    }
                }
                for (Node<?> n : costedCulural.pathList) {
                    if (lastn != null) {
                        line = new Line(Double.parseDouble(n.data.toString().substring(0, 3)), Double.parseDouble(n.data.toString().substring(3, 6)),
                                Double.parseDouble(lastn.data.toString().substring(0, 3)), Double.parseDouble(lastn.data.toString().substring(3, 6)));
                        line.setStroke(Color.RED);
                        pane.getChildren().add(line);
                    }
                    lastn = n;
                }
                System.out.println("\nThe total path cost is: " + costedCulural.pathCost);


                // BFS route
            } else if (bfs.isSelected()) {
                System.out.println("------------------------------------------");
                List<Node<?>> bfsPath = Node.findPathBreadthFirst(first, dest);
                // Draws route on the map
                for (Node<?> n : bfsPath) {
                    if (lastn != null) {
                        line = new Line(Double.parseDouble(n.data.toString().substring(0, 3)), Double.parseDouble(n.data.toString().substring(3, 6)),
                                Double.parseDouble(lastn.data.toString().substring(0, 3)), Double.parseDouble(lastn.data.toString().substring(3, 6)));
                        line.setStroke(Color.RED);
                        pane.getChildren().add(line);
                    }
                    lastn = n;
                }
            }
            if (show.isSelected())
                show.setSelected(false);
            //Re-add Nodes
            if (avoid.getSelectionModel().getSelectedIndex() != -1) {
                reconnectNodes(nodesAvoided, avoidNodes);
            }
        }
    }

    // Change the language of the program
    public void setLanguage(){
        String value = (String) language.getValue();     
        // English
        if (value == "English"){                                                                          
            flag.setImage(english);                                                                          
            set.setText("Set");
            routeSearch.setText("Route Search Method:");                                                                          
            routeType.setText("Route Type:");                                                                          
            djikstra.setText("Djikstra's Algorithm");                                                                          
            bfs.setText("Breadth-First Search");                                                                          
            shortest.setText("Shortest Route");                                                                          
            cultural.setText("Cultural/Historical Route");                                                                          
            msLand.setText("Must-See Landmarks:");                                                                          
            avLand.setText("Avoid Landmarks:");                                                                          
            show.setText("Show Landmarks");                                                                          
            options.setText("Options");                                                                          
            exit.setText("Exit");
            findRoute.setText("Find Route");
            start1.setText("Start:");
            destination1.setText("Destination:");
            show1.setText("Show Junctions");
        } else {
            // Italian
            flag.setImage(italian);                                                                          
            set.setText("Impostato");                                                                          
            routeSearch.setText("Metodo di ricerca del percorso:");                                                                          
            routeType.setText("Tipo di percorso:");                                                                          
            djikstra.setText("L'algoritmo di Dijkstra");                                                                          
            bfs.setText("Prima larghezza di ricerca");                                                                          
            shortest.setText("Percorso più breve");                                                                          
            cultural.setText("Itinerario storico / culturale");                                                                         
            msLand.setText("Punti di riferimento assolutamente da vedere:");                                                                         
            avLand.setText("Evita i punti di riferimento:");                                                                         
            show.setText("Mostra punti di riferimento");                                                                         
            options.setText("Opzioni");                                                                         
            exit.setText("Uscita");
            findRoute.setText("Trova percorso");
            start1.setText("Inizio:");
            destination1.setText("Destinazione:");
            show1.setText("Mostra giunzioni");
        }                                                                         
    }

    // List of nodes to avoid
    public List<NodeLink>[] avoidnodes(int[] avoidArray){
        List<NodeLink>[]  retNodes = new List[avoidArray.length];
        for(int i = 0; i < avoidArray.length; i++){
            retNodes[i] = landmarks[avoidArray[i]].avoidNode();
        }
        return retNodes;
    }
    
    // Reconnects nodes for new routes
    public void reconnectNodes(List<NodeLink>[] avoidNodes, int[] avoidArray){
        for(int i = 0; i < avoidNodes.length; i++){
            landmarks[avoidArray[i]].reconnectNodes(landmarks[avoidArray[i]],avoidNodes[i]);
        }
    }

    // Only allows one algorithm at a time 
    public void searchMethod1(){                                                                         
        if (djikstra.isSelected()){                                                                         
            bfs.setSelected(false);                                                                         
        } else {                                                                         
            bfs.setSelected(true);                                                                         
        }
    }                                                                         
          
    // Only allows one algorithm at a time
    public void searchMethod2(){                                                                         
        if (bfs.isSelected()){                                                                         
            djikstra.setSelected(false); } else {                                                                         
            djikstra.setSelected(true);                                                                         
        }                                                                         
    }                                                                         
                          
    // Only allows one route type
    public void routeType1(){                                                                         
        if (shortest.isSelected()){                                                                         
            cultural.setSelected(false);                                                                         
            bfs.setDisable(false);                                                                         
        } else {                                                                         
            cultural.setSelected(true);                                                                         
            shortest.setSelected(false);                                                                         
            djikstra.setSelected(true);                                                                         
            bfs.setDisable(true);                                                                         
        }                                                                         
    }                                                                         
                      
    // Only allows one route type
    public void routeType2(){                                                                         
        if (cultural.isSelected()){                                                                         
            shortest.setSelected(false);                                                                         
            djikstra.setSelected(true);                                                                         
            bfs.setSelected(false);                                                                         
            bfs.setDisable(true);                                                                         
        } else {                                                                         
            shortest.setSelected(true);                                                                         
            bfs.setDisable(false);                                                                         
        }                                                                         
    }                                                                         

    /**
     * Saves to XML
     * @throws Exception
     */
    
    // Save method for storing nodes, connections and arrays
    public void save() throws Exception {
        XStream xstream = new XStream(new DomDriver());
        ObjectOutputStream out = xstream.createObjectOutputStream(new FileWriter("marks.xml"));
        out.writeObject(landmarks);
        out.writeObject(junctions);
        out.writeObject(xCoordsJunctions);
        out.writeObject(yCoordsJunctions);
        System.out.println("Saved");
        out.close();
    }

    /**
     * Loads from XML
     * @throws Exception
     */
    
    // Loads nodes, connections and arrays into the program
    @SuppressWarnings("unchecked")
    private void load() throws Exception {
        XStream xstream = new XStream(new DomDriver());
        ObjectInputStream is = xstream.createObjectInputStream(new FileReader("marks.xml"));
        landmarks = (Node<Coordinate>[]) is.readObject();
        junctions = (Node<Coordinate>[]) is.readObject();
        xCoordsJunctions = (int[]) is.readObject();
        yCoordsJunctions = (int[]) is.readObject();
        is.close();
    }

    public void quit(){
        System.exit(0);                                                                         
    }                                                                         
}