package RouteFinder;

//IMPORTS
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Node<T>{

    public T data;
    public int nodeValue=Integer.MAX_VALUE;
    public List<NodeLink> adjListLink=new ArrayList<>();
    public List<Node<T>> adjList=new ArrayList<>();

    public Node(T data) {
        this.data=data;
    }

    // Connects each directly for Djikstra
    public void connectToNodeDirectedDijk(Node<?> destNode, int cost) {
        adjListLink.add(new NodeLink(destNode,cost));
    }

    // Connects each node directly for BFS
    public void connectToNodeDirectedBFS(Node<?> destNode) {
        adjList.add((Node<T>) destNode);
    }

    // Connects nodes undirectly
    public void connectToNodeUndirected(Node<T> destNode, int cost) {
        //dijk
        adjListLink.add(new NodeLink(destNode,cost));
        destNode.adjListLink.add(new NodeLink(this,cost));
        //bfs
        adjList.add(destNode);
        destNode.adjList.add(this);
    }

    // Avoids a specified node
    public List<NodeLink> avoidNode() {
        List<NodeLink> removedLinks = new ArrayList<>();

        for(int i = 0; i < this.adjListLink.size(); i++){
            for(int j = 0; j < this.adjListLink.get(i).destNode.adjListLink.size(); j++){
                if(this.data == this.adjListLink.get(i).destNode.adjListLink.get(j).destNode.data){
                    removedLinks.add(this.adjListLink.get(i) /*.destNode .adjListLink.get(j) */);
                    this.adjListLink.get(i).destNode.adjListLink.remove(this.adjListLink.get(i).destNode.adjListLink.get(j));
                }
            }
            this.adjList.get(i).adjList.remove(this);
        }
        return removedLinks;
    }

    // Reconnects any disconnected nodes
    public void reconnectNodes(Node<?> nodeToConnect,List<NodeLink> connections){
        for(int i = 0 ; i < connections.size();i++){
            connections.get(i).destNode.connectToNodeDirectedDijk(nodeToConnect, connections.get(i).cost);
            connections.get(i).destNode.connectToNodeDirectedBFS(nodeToConnect);
        }
    }

    ////////////////////////////////////////////////BFS////////////////////////////////////////////////////////
    // Finds shortest method using BFS
    public static <T> List<Node<?>> findPathBreadthFirst(Node<?> startNode, T lookingfor){
        List<List<Node<?>>> agenda=new ArrayList<>();
        List<Node<?>> firstAgendaPath=new ArrayList<>(),resultPath;
        firstAgendaPath.add(startNode);
        agenda.add(firstAgendaPath);
        resultPath=findPathBreadthFirst(agenda,null,lookingfor);
        Collections.reverse(resultPath);
        return resultPath;
    }

    public static <T> List<Node<?>> findPathBreadthFirst(List<List<Node<?>>> agenda, List<Node<?>> encountered, T lookingfor){
        if(agenda.isEmpty()) return null;
        List<Node<?>> nextPath=agenda.remove(0);
        Node<?> currentNode=nextPath.get(0);
        if(currentNode.data.equals(lookingfor))
            return nextPath;
        if(encountered==null) encountered=new ArrayList<>();
        encountered.add(currentNode);
        for(Node<?> adjNode : currentNode.adjList)
            if(!encountered.contains(adjNode)) {
                List<Node<?>> newPath=new ArrayList<>(nextPath);
                newPath.add(0,adjNode);
                agenda.add(newPath);
            }
        return findPathBreadthFirst(agenda,encountered,lookingfor);
    }

    ////////////////////////////////////////////////Dijkstras//////////////////////////////////////////////////
    // Keeps track of cost of path
    public static class CostedPath{
        public int pathCost=0;
        public List<Node<?>> pathList=new ArrayList<>();
    }

    // Finds shortest Djikstra route
    public static <T> CostedPath findCheapestPathDijkstra(Node<?> startNode, T lookingfor){
        CostedPath cp=new CostedPath();
        List<Node<?>> encountered=new ArrayList<>(), unencountered=new ArrayList<>();
        startNode.nodeValue=0;
        unencountered.add(startNode);
        Node<?> currentNode;
        do{
            currentNode=unencountered.remove(0);
            encountered.add(currentNode);

            if(currentNode.data.equals(lookingfor)){
                cp.pathList.add(currentNode);
                cp.pathCost=currentNode.nodeValue;

                while(currentNode!=startNode) {
                    boolean foundPrevPathNode=false;
                    for(Node<?> n : encountered) {
                        for(NodeLink e : n.adjListLink)
                            if(e.destNode==currentNode && currentNode.nodeValue-e.cost==n.nodeValue){
                                cp.pathList.add(0,n);
                                currentNode=n;
                                foundPrevPathNode=true;
                                break;
                            }
                        if(foundPrevPathNode) break;
                    }
                }

                for(Node<?> n : encountered) n.nodeValue=Integer.MAX_VALUE;
                for(Node<?> n : unencountered) n.nodeValue=Integer.MAX_VALUE;
                return cp;
            }

            for(NodeLink e : currentNode.adjListLink)
                if(!encountered.contains(e.destNode)) {
                    e.destNode.nodeValue=Integer.min(e.destNode.nodeValue, currentNode.nodeValue+e.cost);
                    unencountered.add(e.destNode);
                }
            Collections.sort(unencountered,(n1, n2)->n1.nodeValue-n2.nodeValue);
        }while(!unencountered.isEmpty());
        return null;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    /*
    For avoiding landmarmks we get the land mark and all of it links and delete them
    then do the serach and then re add it back to the list after searching
     */
}