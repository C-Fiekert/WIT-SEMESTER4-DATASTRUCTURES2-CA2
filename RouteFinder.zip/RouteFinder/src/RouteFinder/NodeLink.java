package RouteFinder;

public class NodeLink {
    public Node<?> destNode;
    public int cost;

    // Creates each node which contains destination node and the link cost
    public NodeLink(Node<?> destNode, int cost) {
        this.destNode = destNode;
        this.cost = cost;
    }
}